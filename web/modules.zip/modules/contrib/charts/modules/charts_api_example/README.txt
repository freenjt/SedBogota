To see the example, navigate to:

/charts/example/display

Settings for this chart derive from the Charts module's 
default settings, which are configured here:

/admin/config/content/charts
