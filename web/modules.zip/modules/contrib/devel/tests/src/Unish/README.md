Running Unish Tests
===================

Follow instructions provided by [Drush test README.md](https://github.com/drush-ops/drush/blob/master/tests/README.md) in order to test Unish test cases provided by contrib modules.

See: https://github.com/drush-ops/drush/blob/master/tests/README.md