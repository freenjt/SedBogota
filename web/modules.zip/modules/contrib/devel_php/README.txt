Devel PHP
---------

The Execute feature has been removed from the Devel module for Drupal 8 since version 1.3. This module re-adds back that
feature as an external module.

Just enable devel_php as any other module and go to /devel/php to use it, or add the Execute PHP widget to the Devel
Toolbar (/admin/config/development/devel/toolbar).
